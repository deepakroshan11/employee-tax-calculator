package com.example.emptax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmptaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmptaxApplication.class, args);
	}
	
}
