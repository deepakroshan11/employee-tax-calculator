import { Box, Typography } from '@mui/material';
import React from 'react';

const UserPage = () => {
return (
    <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
    <Typography variant="h4">
        Now you are a user for this income tax calculator.
    </Typography>
    </Box>
);
};

export default UserPage;